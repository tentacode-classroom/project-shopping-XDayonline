CREATE PROCEDURE AddGeometryColumn(IN catalog         VARCHAR(64), IN t_schema VARCHAR(64), IN t_name VARCHAR(64),
                                   IN geometry_column VARCHAR(64), IN t_srid INT)
  begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' ADD ', geometry_column,' GEOMETRY REF_SYSTEM_ID=', t_srid); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end;

